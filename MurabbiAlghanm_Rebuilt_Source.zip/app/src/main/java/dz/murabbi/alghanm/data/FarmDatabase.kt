package dz.murabbi.alghanm.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "animals")
data class Animal(
    @PrimaryKey val tag: String,
    val sex: String,
    val category: String,
    val weightKg: Double,
    val birthDate: String = "",
    val motherTag: String = "",
    val fatherTag: String = "",
    val active: Boolean = true,
    val archiveReason: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "feed_purchases")
data class FeedPurchase(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val feedName: String,
    val quantityKg: Double,
    val totalPriceDzd: Double? = null,
    val supplier: String = "",
    val purchaseDate: String
)

@Entity(tableName = "farm_tasks")
data class FarmTask(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val taskType: String,
    val taskDate: String,
    val animalCount: Int,
    val notes: String = "",
    val completed: Boolean = false
)

@Entity(tableName = "herd_events")
data class HerdEvent(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val animalTag: String,
    val eventType: String,
    val eventDate: String,
    val notes: String = ""
)

@Dao
interface FarmDao {
    @Query("SELECT * FROM animals WHERE active = 1 ORDER BY tag")
    fun activeAnimals(): Flow<List<Animal>>

    @Query("SELECT * FROM animals ORDER BY createdAt DESC")
    fun allAnimals(): Flow<List<Animal>>

    @Query("SELECT * FROM animals WHERE tag = :tag LIMIT 1")
    fun animalByTag(tag: String): Flow<Animal?>

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertAnimal(animal: Animal)

    @Update
    suspend fun updateAnimal(animal: Animal)

    @Query("UPDATE animals SET active = 0, archiveReason = :reason WHERE tag = :tag")
    suspend fun archiveAnimal(tag: String, reason: String)

    @Insert
    suspend fun addPurchase(purchase: FeedPurchase)

    @Query("SELECT * FROM feed_purchases ORDER BY id DESC")
    fun purchases(): Flow<List<FeedPurchase>>

    @Insert
    suspend fun addTask(task: FarmTask)

    @Query("SELECT * FROM farm_tasks ORDER BY taskDate DESC, id DESC")
    fun tasks(): Flow<List<FarmTask>>

    @Insert
    suspend fun addEvent(event: HerdEvent)

    @Query("SELECT * FROM herd_events WHERE animalTag = :tag ORDER BY eventDate DESC, id DESC")
    fun eventsForAnimal(tag: String): Flow<List<HerdEvent>>

    @Query("SELECT * FROM herd_events ORDER BY id DESC")
    fun events(): Flow<List<HerdEvent>>

    @Query("SELECT COUNT(*) FROM animals WHERE active = 1")
    fun activeCount(): Flow<Int>
}

@Database(
    entities = [Animal::class, FeedPurchase::class, FarmTask::class, HerdEvent::class],
    version = 1,
    exportSchema = true
)
abstract class FarmDatabase : RoomDatabase() {
    abstract fun farmDao(): FarmDao

    companion object {
        @Volatile private var INSTANCE: FarmDatabase? = null
        fun get(context: Context): FarmDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    FarmDatabase::class.java,
                    "murabbi_alghanm.db"
                ).build().also { INSTANCE = it }
            }
    }
}
