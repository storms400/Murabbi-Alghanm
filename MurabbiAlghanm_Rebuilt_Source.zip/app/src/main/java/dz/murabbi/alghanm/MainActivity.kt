package dz.murabbi.alghanm

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.ViewModelProvider
import androidx.room.Room
import dz.murabbi.alghanm.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate

private val Forest = Color(0xFF123C32)
private val Emerald = Color(0xFF1F624D)
private val Gold = Color(0xFFD6AD59)
private val Ivory = Color(0xFFF6F3EA)
private val Ink = Color(0xFF24352F)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = FarmDatabase.get(this).farmDao()
        val factory = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T =
                FarmViewModel(dao) as T
        }
        setContent {
            val colors = lightColorScheme(
                primary = Forest,
                secondary = Gold,
                background = Ivory,
                surface = Color.White,
                onPrimary = Color.White,
                onBackground = Ink,
                onSurface = Ink
            )
            CompositionLocalProvider(LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl) {
                MaterialTheme(colorScheme = colors, typography = Typography()) {
                    val vm: FarmViewModel = viewModel(factory = factory)
                    FarmScreen(vm)
                }
            }
        }
    }
}

class FarmViewModel(private val dao: FarmDao) : ViewModel() {
    val animals = dao.activeAnimals().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val purchases = dao.purchases().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val tasks = dao.tasks().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addAnimal(tag: String, sex: String, category: String, weight: Double, birth: String, mother: String, father: String, onError: (String) -> Unit) {
        viewModelScope.launch {
            try {
                dao.insertAnimal(Animal(tag.trim(), sex, category, weight, birth, mother, father))
            } catch (_: Exception) { onError("تعذر الحفظ: رقم الحيوان موجود مسبقاً.") }
        }
    }
    fun updateAnimal(animal: Animal) { viewModelScope.launch { dao.updateAnimal(animal) } }
    fun archive(animal: Animal) { viewModelScope.launch { dao.archiveAnimal(animal.tag, "أرشفة يدوية") } }
    fun addPurchase(name: String, qty: Double, price: Double?, supplier: String) {
        viewModelScope.launch { dao.addPurchase(FeedPurchase(feedName=name, quantityKg=qty, totalPriceDzd=price, supplier=supplier, purchaseDate=LocalDate.now().toString())) }
    }
    fun addTask(type: String, count: Int, notes: String) {
        viewModelScope.launch { dao.addTask(FarmTask(taskType=type, taskDate=LocalDate.now().toString(), animalCount=count, notes=notes)) }
    }
    fun addEvent(tag: String, type: String, notes: String) {
        viewModelScope.launch { dao.addEvent(HerdEvent(animalTag=tag, eventType=type, eventDate=LocalDate.now().toString(), notes=notes)) }
    }
    fun events(tag: String) = dao.eventsForAnimal(tag)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FarmScreen(vm: FarmViewModel) {
    val animals by vm.animals.collectAsState()
    val purchases by vm.purchases.collectAsState()
    val tasks by vm.tasks.collectAsState()
    var tab by remember { mutableStateOf("الرئيسية") }
    var selectedAnimal by remember { mutableStateOf<Animal?>(null) }
    var showAdd by remember { mutableStateOf(false) }
    var tag by remember { mutableStateOf("") }
    var sex by remember { mutableStateOf("أنثى") }
    var category by remember { mutableStateOf("جافة") }
    var weight by remember { mutableStateOf("45") }
    var birth by remember { mutableStateOf("") }
    var mother by remember { mutableStateOf("") }
    var father by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    var feedName by remember { mutableStateOf("شعير") }
    var quantity by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var supplier by remember { mutableStateOf("") }
    var taskType by remember { mutableStateOf("تنقية الفرشة") }
    var notes by remember { mutableStateOf("") }

    val categories = listOf("جافة", "حامل - جنين واحد", "حامل - توأم", "مرضعة - حمل واحد", "مرضعة - توأم", "فحل", "حمل")
    Scaffold(
        topBar = {
            Column(Modifier.fillMaxWidth().padding(horizontal=16.dp, vertical=12.dp)) {
                Text("🐑 مربي الغنم", color=Forest, style=MaterialTheme.typography.headlineSmall, fontWeight=FontWeight.Bold)
                Text("إدارة المزرعة والقطيع", color=Emerald, style=MaterialTheme.typography.bodyMedium)
            }
        },
        bottomBar = {
            NavigationBar(containerColor=Forest) {
                listOf("الرئيسية","القطيع","المشتريات","الرعاية").forEach { name ->
                    NavigationBarItem(
                        selected=tab==name,
                        onClick={ tab=name; selectedAnimal=null },
                        icon={ Text(when(name) { "الرئيسية"->"⌂"; "القطيع"->"🐑"; "المشتريات"->"🛒"; else->"✓" }, color=if(tab==name) Gold else Color.White) },
                        label={ Text(name, color=Color.White) },
                        colors=NavigationBarItemDefaults.colors(indicatorColor=Emerald, selectedIconColor=Gold, selectedTextColor=Color.White, unselectedTextColor=Color.White)
                    )
                }
            }
        },
        containerColor=Ivory
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal=14.dp)) {
            when {
                selectedAnimal != null -> AnimalProfile(
                    animal=selectedAnimal!!,
                    eventsFlow=vm.events(selectedAnimal!!.tag),
                    onBack={selectedAnimal=null},
                    onSave={ vm.updateAnimal(it); selectedAnimal=it },
                    onArchive={ vm.archive(it); selectedAnimal=null },
                    onAddEvent={ type, note -> vm.addEvent(selectedAnimal!!.tag,type,note) }
                )
                tab=="الرئيسية" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement=Arrangement.spacedBy(12.dp)) {
                    Card(colors=CardDefaults.cardColors(containerColor=Forest), shape=RoundedCornerShape(22.dp), modifier=Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(20.dp)) {
                            Text("ملخص القطيع", color=Gold, fontWeight=FontWeight.Bold)
                            Text("${animals.size} رأس", color=Color.White, style=MaterialTheme.typography.headlineLarge, fontWeight=FontWeight.Bold)
                            Text("الأعداد تتحدث تلقائياً حسب السجلات النشطة", color=Color.White.copy(alpha=.8f))
                        }
                    }
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        StatCard("النعاج", animals.count{it.sex=="أنثى"}.toString(), Modifier.weight(1f))
                        StatCard("الحوامل", animals.count{it.category.startsWith("حامل")}.toString(), Modifier.weight(1f))
                    }
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                        StatCard("المرضعات", animals.count{it.category.startsWith("مرضعة")}.toString(), Modifier.weight(1f))
                        StatCard("الحملان", animals.count{it.category=="حمل"}.toString(), Modifier.weight(1f))
                    }
                    Text("مهام الحظيرة", style=MaterialTheme.typography.titleLarge, color=Forest, fontWeight=FontWeight.Bold)
                    if (tasks.isEmpty()) Text("لا توجد مهام مسجلة بعد.")
                    tasks.take(4).forEach { ListItem(headlineContent={Text(it.taskType)}, supportingContent={Text("${it.taskDate} · ${it.animalCount} رأس")}) }
                }
                tab=="القطيع" -> Column(Modifier.fillMaxSize()) {
                    Button(onClick={showAdd=!showAdd}, modifier=Modifier.fillMaxWidth(), colors=ButtonDefaults.buttonColors(containerColor=Forest)) { Text(if(showAdd) "إغلاق نموذج الإضافة" else "＋ إضافة حيوان") }
                    if(showAdd) {
                        OutlinedTextField(tag,{tag=it},label={Text("رقم الحيوان")},modifier=Modifier.fillMaxWidth())
                        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                            listOf("أنثى","ذكر").forEach { FilterChip(selected=sex==it,onClick={sex=it},label={Text(it)}) }
                        }
                        var expanded by remember { mutableStateOf(false) }
                        ExposedDropdownMenuBox(expanded=expanded,onExpandedChange={expanded=!expanded}) {
                            OutlinedTextField(category,{category=it},readOnly=true,label={Text("الفئة")},modifier=Modifier.menuAnchor().fillMaxWidth())
                            ExposedDropdownMenu(expanded=expanded,onDismissRequest={expanded=false}) {
                                categories.forEach { DropdownMenuItem(text={Text(it)},onClick={category=it;expanded=false}) }
                            }
                        }
                        OutlinedTextField(weight,{weight=it},label={Text("الوزن بالكيلوغرام")},modifier=Modifier.fillMaxWidth())
                        OutlinedTextField(birth,{birth=it},label={Text("تاريخ الميلاد (اختياري)")},modifier=Modifier.fillMaxWidth())
                        OutlinedTextField(mother,{mother=it},label={Text("رقم الأم (اختياري)")},modifier=Modifier.fillMaxWidth())
                        OutlinedTextField(father,{father=it},label={Text("رقم الأب (اختياري)")},modifier=Modifier.fillMaxWidth())
                        if(error.isNotBlank()) Text(error,color=MaterialTheme.colorScheme.error)
                        Button(onClick={
                            val w=weight.toDoubleOrNull()
                            if(tag.isBlank()||w==null||w<=0) error="أدخل رقم الحيوان ووزناً صحيحاً."
                            else { vm.addAnimal(tag,sex,category,w,birth,mother,father){error=it}; tag=""; weight="45"; birth=""; mother=""; father=""; error=""; showAdd=false }
                        }, modifier=Modifier.fillMaxWidth(), colors=ButtonDefaults.buttonColors(containerColor=Emerald)) { Text("حفظ الحيوان") }
                    }
                    LazyColumn(verticalArrangement=Arrangement.spacedBy(6.dp)) {
                        items(animals,key={it.tag}) { a ->
                            Card(Modifier.fillMaxWidth().clickable { selectedAnimal=a }, colors=CardDefaults.cardColors(containerColor=Color.White), shape=RoundedCornerShape(16.dp)) {
                                Row(Modifier.padding(14.dp), verticalAlignment=Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text("الحيوان ${a.tag}", color=Forest, fontWeight=FontWeight.Bold)
                                        Text("${a.category} · ${a.sex} · ${a.weightKg} كغ", color=Ink)
                                    }
                                    Text("فتح الملف  ›", color=Emerald, fontWeight=FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
                tab=="المشتريات" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement=Arrangement.spacedBy(8.dp)) {
                    Text("تسجيل شراء علف",style=MaterialTheme.typography.titleLarge,color=Forest,fontWeight=FontWeight.Bold)
                    OutlinedTextField(feedName,{feedName=it},label={Text("نوع العلف")},modifier=Modifier.fillMaxWidth())
                    OutlinedTextField(quantity,{quantity=it},label={Text("الكمية بالكغ")},modifier=Modifier.fillMaxWidth())
                    OutlinedTextField(price,{price=it},label={Text("السعر الإجمالي بالدينار (اختياري)")},modifier=Modifier.fillMaxWidth())
                    OutlinedTextField(supplier,{supplier=it},label={Text("المورد")},modifier=Modifier.fillMaxWidth())
                    Button(onClick={
                        val q=quantity.toDoubleOrNull(); val p=if(price.isBlank()) null else price.toDoubleOrNull()
                        if(q!=null&&q>0&&(price.isBlank()||(p!=null&&p>=0))) { vm.addPurchase(feedName,q,p,supplier); quantity=""; price=""; supplier="" }
                    },modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Forest)){Text("حفظ عملية الشراء")}
                    Text("السعر الفارغ يعني غير معروف، ولا يُعامل كصفر.", color=Ink)
                    purchases.forEach { ListItem(headlineContent={Text("${it.feedName} · ${it.quantityKg} كغ")},supportingContent={Text("${it.purchaseDate} · ${it.supplier}")},trailingContent={Text(it.totalPriceDzd?.let{"$it دج"}?: "غير معروف")}) }
                }
                else -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement=Arrangement.spacedBy(8.dp)) {
                    Text("أعمال الحظيرة والجز",style=MaterialTheme.typography.titleLarge,color=Forest,fontWeight=FontWeight.Bold)
                    OutlinedTextField(taskType,{taskType=it},label={Text("نوع العمل")},modifier=Modifier.fillMaxWidth())
                    OutlinedTextField(notes,{notes=it},label={Text("ملاحظات")},modifier=Modifier.fillMaxWidth())
                    Button(onClick={vm.addTask(taskType,animals.size,notes);notes=""},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Forest)){Text("تسجيل العمل اليوم")}
                    tasks.forEach { ListItem(headlineContent={Text(it.taskType)},supportingContent={Text("${it.taskDate} · ${it.animalCount} رأس · ${it.notes}")}) }
                    Text("يُحدد توقيت الجز والتنظيف وفق الطقس والرطوبة وحالة القطيع.")
                }
            }
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors=CardDefaults.cardColors(containerColor=Color.White), shape=RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(value, color=Emerald, style=MaterialTheme.typography.headlineMedium, fontWeight=FontWeight.Bold)
            Text(label, color=Ink)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AnimalProfile(
    animal: Animal,
    eventsFlow: Flow<List<HerdEvent>>,
    onBack: () -> Unit,
    onSave: (Animal) -> Unit,
    onArchive: (Animal) -> Unit,
    onAddEvent: (String,String) -> Unit
) {
    val events by eventsFlow.collectAsState(initial=emptyList())
    var weight by remember(animal.tag) { mutableStateOf(animal.weightKg.toString()) }
    var category by remember(animal.tag) { mutableStateOf(animal.category) }
    var birth by remember(animal.tag) { mutableStateOf(animal.birthDate) }
    var mother by remember(animal.tag) { mutableStateOf(animal.motherTag) }
    var father by remember(animal.tag) { mutableStateOf(animal.fatherTag) }
    var eventType by remember { mutableStateOf("وزن") }
    var note by remember { mutableStateOf("") }
    val eventTypes = listOf("تلقيح","حمل","ولادة","علاج","لقاح","وزن","ملاحظة")
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement=Arrangement.spacedBy(8.dp)) {
        TextButton(onClick=onBack) { Text("‹ العودة إلى القطيع") }
        Text("ملف الحيوان ${animal.tag}", style=MaterialTheme.typography.titleLarge, color=Forest, fontWeight=FontWeight.Bold)
        Text("${animal.sex} · ${if(animal.active) "نشط" else "مؤرشف"}")
        OutlinedTextField(weight,{weight=it},label={Text("الوزن بالكغ")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(category,{category=it},label={Text("الفئة")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(birth,{birth=it},label={Text("تاريخ الميلاد")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(mother,{mother=it},label={Text("رقم الأم")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(father,{father=it},label={Text("رقم الأب")},modifier=Modifier.fillMaxWidth())
        Button(onClick={weight.toDoubleOrNull()?.let { if(it>0) onSave(animal.copy(weightKg=it,category=category,birthDate=birth,motherTag=mother,fatherTag=father)) }},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Forest)){Text("حفظ التعديلات")}
        OutlinedButton(onClick={onArchive(animal)},modifier=Modifier.fillMaxWidth()){Text("أرشفة الحيوان")}
        Divider()
        Text("تسجيل حدث جديد", style=MaterialTheme.typography.titleMedium, color=Forest, fontWeight=FontWeight.Bold)
        var expanded by remember { mutableStateOf(false) }
        ExposedDropdownMenuBox(expanded=expanded,onExpandedChange={expanded=!expanded}) {
            OutlinedTextField(eventType,{eventType=it},readOnly=true,label={Text("نوع الحدث")},modifier=Modifier.menuAnchor().fillMaxWidth())
            ExposedDropdownMenu(expanded=expanded,onDismissRequest={expanded=false}) {
                eventTypes.forEach { DropdownMenuItem(text={Text(it)},onClick={eventType=it;expanded=false}) }
            }
        }
        OutlinedTextField(note,{note=it},label={Text("ملاحظات")},modifier=Modifier.fillMaxWidth())
        Button(onClick={onAddEvent(eventType,note);note=""},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Emerald)){Text("تسجيل الحدث")}
        Text("سجل الأحداث",style=MaterialTheme.typography.titleMedium,color=Forest,fontWeight=FontWeight.Bold)
        if(events.isEmpty()) Text("لا توجد أحداث مسجلة لهذا الحيوان.")
        events.forEach { ListItem(headlineContent={Text(it.eventType)},supportingContent={Text("${it.eventDate} · ${it.notes}")}) }
    }
}
